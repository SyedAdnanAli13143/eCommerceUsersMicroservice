﻿namespace eCommerce.Core.DTO;

public enum GenderOptions
{
    Male, Female, Others
}